package org.usfirst.frc.team1895.robot.enums;

public enum F310Buttons {
	A, B, X, Y, LB, RB, BACK, START, LAXIS, RAXIS
}
