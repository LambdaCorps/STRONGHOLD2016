package org.usfirst.frc.team1895.robot.enums;

public enum F310Axis {
	LX, LY, LT, RT, RX, RY
}
