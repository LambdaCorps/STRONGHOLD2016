package org.usfirst.frc.team1895.robot.custom;

import edu.wpi.first.wpilibj.Joystick;

public class ArcadeStick extends Joystick {

	public ArcadeStick(int port) {
		super(port);
		
	}

}
